"""
================================================================
  Historical CAPA Records — PostgreSQL Setup
================================================================
  Run ONCE to:
    1. Create table historical_capa_records
    2. Create all indexes
    3. Insert all 1000 records from CSV
    4. Verify with summary queries

  Usage:
    Step 1 — Create database (in terminal):
        psql -U postgres -c "CREATE DATABASE capa_db;"

    Step 2 — Update DB_CONFIG password below

    Step 3 — Run:
        python3 setup_postgres.py
================================================================
"""

import sys
import os
import pandas as pd
from sqlalchemy import create_engine, text

# ── CONFIG ─────────────────────────────────────────────────────
DB_CONFIG = {
    "host"    : "localhost",
    "port"    : 5432,
    "database": "capa_db",
    "user"    : "postgres",
    "password": "yourpassword",      # ← change this
}
CSV_PATH = os.path.join(os.path.dirname(__file__), "historical_capa_records.csv")
# ───────────────────────────────────────────────────────────────


# ── TABLE DDL ──────────────────────────────────────────────────

DDL_TABLE = """
CREATE TABLE IF NOT EXISTS historical_capa_records (

    id                      SERIAL          PRIMARY KEY,

    -- Identification
    capa_id                 VARCHAR(30)     NOT NULL UNIQUE,
    open_date               DATE            NOT NULL,
    close_date              DATE,
    days_to_close           INTEGER,

    -- Context
    product                 VARCHAR(150),
    department              VARCHAR(70),
    severity                VARCHAR(10)
                            CHECK (severity IN ('High','Medium','Low')),
    root_cause              VARCHAR(100),
    regulatory_reference    VARCHAR(100),

    -- Core CAPA content (used by recommendation engine)
    incident_summary        TEXT            NOT NULL,
    root_cause_detail       TEXT,
    corrective_action       TEXT,
    preventive_action       TEXT,
    effectiveness_check     TEXT,

    -- Outcome (used for ranking recommendations)
    effectiveness_rating    VARCHAR(25)
                            CHECK (effectiveness_rating IN (
                                'Effective',
                                'Partially Effective',
                                'Not Effective'
                            )),
    recurrence              VARCHAR(5)
                            CHECK (recurrence IN ('Yes','No')),

    -- People
    investigator_name       VARCHAR(60),
    investigator_role       VARCHAR(60),
    approver_name           VARCHAR(60),
    approver_role           VARCHAR(60),

    -- Timeline
    ca_completion_date      DATE,
    pa_completion_date      DATE,
    ec_completion_date      DATE,

    -- Audit
    created_at              TIMESTAMP       DEFAULT NOW()
);
"""

DDL_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_hcr_root_cause    ON historical_capa_records (root_cause);",
    "CREATE INDEX IF NOT EXISTS idx_hcr_severity       ON historical_capa_records (severity);",
    "CREATE INDEX IF NOT EXISTS idx_hcr_effectiveness  ON historical_capa_records (effectiveness_rating);",
    "CREATE INDEX IF NOT EXISTS idx_hcr_department     ON historical_capa_records (department);",
    "CREATE INDEX IF NOT EXISTS idx_hcr_recurrence     ON historical_capa_records (recurrence);",
    "CREATE INDEX IF NOT EXISTS idx_hcr_open_date      ON historical_capa_records (open_date);",
    "CREATE INDEX IF NOT EXISTS idx_hcr_rc_eff         ON historical_capa_records (root_cause, effectiveness_rating);",
    "CREATE INDEX IF NOT EXISTS idx_hcr_sev_eff        ON historical_capa_records (severity, effectiveness_rating);",
]

INSERT_SQL = """
INSERT INTO historical_capa_records (
    capa_id, open_date, close_date, days_to_close,
    product, department, severity, root_cause, regulatory_reference,
    incident_summary, root_cause_detail, corrective_action,
    preventive_action, effectiveness_check,
    effectiveness_rating, recurrence,
    investigator_name, investigator_role,
    approver_name, approver_role,
    ca_completion_date, pa_completion_date, ec_completion_date
)
VALUES (
    :capa_id, :open_date, :close_date, :days_to_close,
    :product, :department, :severity, :root_cause, :regulatory_reference,
    :incident_summary, :root_cause_detail, :corrective_action,
    :preventive_action, :effectiveness_check,
    :effectiveness_rating, :recurrence,
    :investigator_name, :investigator_role,
    :approver_name, :approver_role,
    :ca_completion_date, :pa_completion_date, :ec_completion_date
)
ON CONFLICT (capa_id) DO NOTHING;
"""

# ── FUNCTIONS ──────────────────────────────────────────────────

def connect():
    url = (
        f"postgresql+psycopg2://{DB_CONFIG['user']}:{DB_CONFIG['password']}"
        f"@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
    )
    try:
        engine = create_engine(url)
        with engine.connect() as c:
            c.execute(text("SELECT 1"))
        print(f"  ✓  Connected → {DB_CONFIG['database']}@{DB_CONFIG['host']}")
        return engine
    except Exception as e:
        print(f"\n  ✗  Connection failed: {e}")
        print(f"\n  Fix:")
        print(f"    psql -U postgres -c \"CREATE DATABASE capa_db;\"")
        print(f"    Update DB_CONFIG password in this script.")
        sys.exit(1)


def create_schema(engine):
    print("\n  Creating table and indexes...")
    with engine.begin() as c:
        c.execute(text(DDL_TABLE))
        for idx in DDL_INDEXES:
            c.execute(text(idx))
    print(f"  ✓  Table   : historical_capa_records (23 columns)")
    print(f"  ✓  Indexes : {len(DDL_INDEXES)} created")


def load_and_insert(engine, csv_path):
    print(f"\n  Loading CSV: {csv_path}")
    df = pd.read_csv(csv_path)
    print(f"  ✓  {len(df)} rows · {len(df.columns)} columns")

    date_cols = ["open_date","close_date","ca_completion_date",
                 "pa_completion_date","ec_completion_date"]
    for col in date_cols:
        df[col] = pd.to_datetime(df[col]).dt.date
    df = df.where(pd.notnull(df), None)

    print(f"\n  Inserting records...")
    records  = df.to_dict(orient="records")
    inserted = 0
    skipped  = 0
    with engine.begin() as c:
        for row in records:
            r = c.execute(text(INSERT_SQL), row)
            inserted += r.rowcount
            skipped  += (1 - r.rowcount)
    print(f"  ✓  Inserted : {inserted}")
    if skipped:
        print(f"  ↷  Skipped  : {skipped} (already existed)")


def verify(engine):
    print("\n" + "─"*52)
    print("  VERIFICATION")
    print("─"*52)
    with engine.connect() as c:

        total = c.execute(
            text("SELECT COUNT(*) FROM historical_capa_records")
        ).scalar()
        print(f"\n  Total records : {total}")

        print(f"\n  By root cause:")
        for r in c.execute(text("""
            SELECT root_cause, COUNT(*) n
            FROM historical_capa_records
            GROUP BY root_cause ORDER BY n DESC
        """)).fetchall():
            print(f"    {r[0]:<35} {r[1]}")

        print(f"\n  By severity:")
        for r in c.execute(text("""
            SELECT severity, COUNT(*) n
            FROM historical_capa_records
            GROUP BY severity ORDER BY n DESC
        """)).fetchall():
            print(f"    {r[0]:<12} {r[1]}")

        print(f"\n  By effectiveness:")
        for r in c.execute(text("""
            SELECT effectiveness_rating, COUNT(*) n
            FROM historical_capa_records
            GROUP BY effectiveness_rating ORDER BY n DESC
        """)).fetchall():
            print(f"    {r[0]:<25} {r[1]}")

        print(f"\n  Effectiveness rate by root cause:")
        for r in c.execute(text("""
            SELECT
                root_cause,
                COUNT(*) total,
                ROUND(100.0*SUM(CASE WHEN effectiveness_rating='Effective'
                               THEN 1 ELSE 0 END)/COUNT(*),1) pct
            FROM historical_capa_records
            GROUP BY root_cause ORDER BY pct DESC
        """)).fetchall():
            print(f"    {r[0]:<35} {r[2]}%  ({r[1]} records)")

        avg = c.execute(text(
            "SELECT ROUND(AVG(days_to_close)) FROM historical_capa_records"
        )).scalar()
        print(f"\n  Avg days to close : {avg} days")

        print(f"\n  Sample effective record:")
        row = c.execute(text("""
            SELECT capa_id, severity, root_cause, department,
                   LEFT(incident_summary,85),
                   LEFT(corrective_action,85),
                   effectiveness_rating, days_to_close
            FROM historical_capa_records
            WHERE effectiveness_rating='Effective' AND severity='High'
            ORDER BY RANDOM() LIMIT 1
        """)).fetchone()
        if row:
            print(f"    capa_id           : {row[0]}")
            print(f"    severity          : {row[1]}  |  root_cause: {row[2]}")
            print(f"    department        : {row[3]}")
            print(f"    incident_summary  : {row[4]}...")
            print(f"    corrective_action : {row[5]}...")
            print(f"    effectiveness     : {row[6]}  |  days_to_close: {row[7]}")

    print("\n" + "─"*52)
    print("  ✓  PostgreSQL database ready")
    print("  ✓  Recommendation engine can now query this table")
    print("─"*52 + "\n")


# ── MAIN ───────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "="*52)
    print("  Historical CAPA Records → PostgreSQL")
    print("="*52)

    engine = connect()
    create_schema(engine)
    load_and_insert(engine, CSV_PATH)
    verify(engine)
